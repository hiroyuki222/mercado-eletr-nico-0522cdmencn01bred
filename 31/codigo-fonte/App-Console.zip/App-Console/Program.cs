﻿using Microsoft.EntityFrameworkCore;

namespace App_Console
{

    // Representação das Tabelas do Banco de dados
    public class Aluno
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Sobrenome { get; set; }

        public Curso? Cursos { get; set; }
    }

    public class Curso
    {
        public int Id { get; set; }
        public string Nome { get; set; }

        // Relacionamento 1:N da tabela Curso com Aluno.
        // 1 Curso pode possuir N Alunos.
        public List<Aluno> Alunos { get; set; } = new List<Aluno>();
    }

    // Banco de dados Escola
    public class DbEscola: DbContext
    {
        // Adição da tabela no banco de dados.
        // Esse atributo ficará responsável por Definir/Capturar valores da tabela Alunos
        public DbSet<Aluno> Alunos { get; set; }
        // Esse atributo ficará responsável por Definir/Capturar valores da tabela Cursos
        public DbSet<Curso> Cursos { get; set; }

        //public DbEscola(DbContextOptions<DbEscola> options): base(options) { }

        protected override void OnModelCreating(ModelBuilder Modelagem)
        {
            Modelagem.Entity<Aluno>(TabelaAluno =>
            {
                // Definindo a PK da Tabela Aluno.
                TabelaAluno.HasKey(Coluna => Coluna.Id);
                // Definindo o nome da Tabela no Database.
                TabelaAluno.ToTable("Alunos");
            });

            Modelagem.Entity<Curso>(TabelaCurso =>
            {
                // Definindo a PK da Tabela Curso.
                TabelaCurso.HasKey(Coluna => Coluna.Id);
                // Definindo o nome da Tabela no Database.
                TabelaCurso.ToTable("Cursos");
                // Definindo o relacionamento 1:N da Tabela Curso com Alunos.
                // 1 Curso pode possuir N Alunos.
                TabelaCurso.HasMany(Tabela => Tabela.Alunos);
            });
        }

        // Configurações de conexão com Banco de dados.
        protected override void OnConfiguring(DbContextOptionsBuilder Configuracao)
        {
            // Credêncial de Conexão com Banco de dados.
            string Credencial = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Escola;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

            // Definição da Conexão em um Banco de dados Sql Server.
            Configuracao.UseSqlServer(Credencial);
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("PoC Relacionamento utilizando Entity Framework");

            var Db = new DbEscola();

            var curso = new Curso
            {
                Nome = "Bootcamp C#",
                Alunos = new List<Aluno>
                {
                    new Aluno
                    {
                        Nome = "Willian",
                        Sobrenome = "Sant Anna"
                    }
                }
            };

            Db.Add(curso);
            Db.SaveChanges();
        }
    }
}