﻿select 
a.Nome, 
a.Sobrenome,
c.Nome as "Nome do Curso"
from Alunos a
	left join Cursos c
		on a.CursosId = c.Id;